package app.ava

import android.app.Application
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class AvaViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx = app.applicationContext
    private val executor = Executor(ctx)
    private val store = HistoryStore(ctx)

    private val _state = MutableStateFlow(UiState(history = store.load()))
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    // فرمانی که منتظر مجوز است
    private var pending: Command? = null
    private var pendingHeard: String = ""

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("fa", "IR"))
                ttsReady = r != null && r >= TextToSpeech.LANG_AVAILABLE
            }
        }
    }

    private fun s(id: Int): String = ctx.getString(id)

    // ---------- شنیدن ----------

    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            finish("", Outcome(Status.FAILED, s(R.string.r_no_recognizer)))
            return
        }
        tts?.stop()
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        recognizer = r
        r.setRecognitionListener(listener)
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        _state.update {
            it.copy(phase = Phase.Listening, heard = "", reply = "", choices = emptyList(), level = 0f)
        }
        r.startListening(i)
    }

    fun onMicDenied() {
        finish("", Outcome(Status.FAILED, s(R.string.r_mic_denied)))
    }

    fun stop() {
        recognizer?.cancel()
        tts?.stop()
        pending = null
        _state.update { it.copy(phase = Phase.Idle, level = 0f, choices = emptyList()) }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onRmsChanged(rmsdB: Float) {
            val lv = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
            _state.update { it.copy(level = lv) }
        }

        override fun onEndOfSpeech() {
            _state.update { it.copy(phase = Phase.Processing, level = 0f) }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!t.isNullOrBlank()) _state.update { it.copy(heard = t) }
        }

        override fun onResults(results: Bundle?) {
            val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (t.isNullOrBlank()) {
                finish("", Outcome(Status.FAILED, s(R.string.r_no_speech)))
            } else {
                handle(t)
            }
        }

        override fun onError(error: Int) {
            val msg = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> R.string.r_no_speech
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> R.string.r_network
                12, 13 -> R.string.r_lang // LANGUAGE_NOT_SUPPORTED / LANGUAGE_UNAVAILABLE
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> R.string.r_need_mic
                else -> R.string.r_error
            }
            // خطای «لغو» (۵) را وقتی خودمان stop زده‌ایم نشان نمی‌دهیم
            if (error == SpeechRecognizer.ERROR_CLIENT) return
            finish("", Outcome(Status.FAILED, s(msg)))
        }
    }

    // ---------- اجرا ----------

    private fun handle(text: String) {
        _state.update { it.copy(phase = Phase.Processing, heard = text) }
        run(text, CommandParser.parse(text))
    }

    private fun run(heard: String, cmd: Command) {
        pending = cmd
        pendingHeard = heard
        viewModelScope.launch {
            val o = withContext(Dispatchers.IO) { executor.execute(cmd) }
            finish(heard, o)
        }
    }

    fun choose(c: Contact) {
        finish(c.name, executor.dial(c))
    }

    fun consumePermissionRequest() {
        _state.update { it.copy(permissionRequest = null) }
    }

    fun onPermissionResult(granted: Boolean) {
        val cmd = pending
        if (granted && cmd != null) {
            _state.update { it.copy(phase = Phase.Processing) }
            run(pendingHeard, cmd)
        } else {
            finish(pendingHeard, Outcome(Status.FAILED, s(R.string.r_contacts_denied)))
        }
    }

    private fun finish(heard: String, o: Outcome) {
        if (o.permission != null) {
            _state.update {
                it.copy(phase = Phase.Idle, reply = o.message, permissionRequest = o.permission, level = 0f)
            }
            speak(o.message)
            return
        }
        pending = null
        val item = HistoryItem(System.currentTimeMillis(), heard, o.message, o.status)
        val history = (listOf(item) + _state.value.history).take(HistoryStore.MAX)
        // خطاهای بدون فرمان (مثل «چیزی نشنیدم») در تاریخچه نمی‌آیند
        if (heard.isNotBlank()) store.save(history)
        _state.update {
            it.copy(
                phase = Phase.Idle,
                reply = o.message,
                choices = o.choices,
                level = 0f,
                history = if (heard.isNotBlank()) history else it.history,
            )
        }
        speak(o.message)
    }

    fun clearHistory() {
        store.clear()
        _state.update { it.copy(history = emptyList()) }
    }

    private fun speak(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ava")
    }

    override fun onCleared() {
        recognizer?.destroy()
        tts?.shutdown()
    }
}
