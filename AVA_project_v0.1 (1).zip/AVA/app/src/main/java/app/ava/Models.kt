package app.ava

/** فرمان‌هایی که آوا می‌فهمد (نسخه ۱). بدون وابستگی به اندروید تا قابل آزمون باشد. */
sealed interface Command {
    data class Call(val name: String) : Command
    data class OpenApp(val name: String) : Command
    data class Media(val action: MediaAction) : Command
    data class Volume(val up: Boolean) : Command
    data class Settings(val kind: SettingsKind, val toggle: Boolean) : Command
    data object MusicSearch : Command
    data object Unknown : Command
}

enum class MediaAction { PLAY, PAUSE, NEXT, PREVIOUS }
enum class SettingsKind { GENERAL, WIFI, BLUETOOTH }

/** نتیجه واقعی اجرا؛ آوا میان این وضعیت‌ها فرق می‌گذارد (بخش ۸ سند مادر). */
enum class Status { DONE, HANDED_OFF, NEEDS_INPUT, FAILED, UNSUPPORTED }

data class Contact(val id: Long, val name: String, val number: String)

data class Outcome(
    val status: Status,
    val message: String,
    val choices: List<Contact> = emptyList(),
    val permission: String? = null,
)

data class HistoryItem(val time: Long, val heard: String, val reply: String, val status: Status)

enum class Phase { Idle, Listening, Processing }

data class UiState(
    val phase: Phase = Phase.Idle,
    val heard: String = "",
    val reply: String = "",
    val choices: List<Contact> = emptyList(),
    val level: Float = 0f,
    val permissionRequest: String? = null,
    val history: List<HistoryItem> = emptyList(),
)
