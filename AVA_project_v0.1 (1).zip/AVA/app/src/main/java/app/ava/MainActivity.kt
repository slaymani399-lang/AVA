package app.ava

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Cyan = Color(0xFF4FD1FF)
private val Dim = Color(0xFF9AA4AD)

enum class Screen { Main, History, Settings }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AvaApp() }
    }
}

@Composable
fun AvaApp(vm: AvaViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    var screen by rememberSaveable { mutableStateOf(Screen.Main) }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.startListening() else vm.onMicDenied()
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        vm.onPermissionResult(ok)
    }
    LaunchedEffect(state.permissionRequest) {
        state.permissionRequest?.let {
            permLauncher.launch(it)
            vm.consumePermissionRequest()
        }
    }

    fun onMic() {
        when {
            state.phase != Phase.Idle -> vm.stop()
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED -> vm.startListening()
            else -> micLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    BackHandler(enabled = screen != Screen.Main) { screen = Screen.Main }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = darkColorScheme(primary = Cyan, background = Color.Black, surface = Color.Black),
        ) {
            Surface(Modifier.fillMaxSize(), color = Color.Black) {
                Box(Modifier.fillMaxSize().systemBarsPadding()) {
                    when (screen) {
                        Screen.Main -> MainScreen(
                            state = state,
                            onMic = ::onMic,
                            onStop = vm::stop,
                            onChoose = vm::choose,
                            onHistory = { screen = Screen.History },
                            onSettings = { screen = Screen.Settings },
                        )
                        Screen.History -> HistoryScreen(
                            items = state.history,
                            onClear = vm::clearHistory,
                            onBack = { screen = Screen.Main },
                        )
                        Screen.Settings -> SettingsScreen(
                            onClear = vm::clearHistory,
                            onBack = { screen = Screen.Main },
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MainScreen(
    state: UiState,
    onMic: () -> Unit,
    onStop: () -> Unit,
    onChoose: (Contact) -> Unit,
    onHistory: () -> Unit,
    onSettings: () -> Unit,
) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onHistory) { Text(stringResource(R.string.btn_history)) }
            Text("AVA", color = Cyan, fontSize = 18.sp)
            TextButton(onClick = onSettings) { Text(stringResource(R.string.btn_settings)) }
        }

        Spacer(Modifier.weight(1f))
        GlowCircle(state.phase, state.level, onMic)
        Spacer(Modifier.height(24.dp))

        Text(
            when (state.phase) {
                Phase.Idle -> stringResource(R.string.status_idle)
                Phase.Listening -> stringResource(R.string.status_listening)
                Phase.Processing -> stringResource(R.string.status_processing)
            },
            color = Dim, fontSize = 15.sp, textAlign = TextAlign.Center,
        )

        Column(
            Modifier.fillMaxWidth().weight(1.2f).verticalScroll(rememberScrollState()).padding(top = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            if (state.heard.isNotBlank()) {
                Text("«${state.heard}»", color = Color.White, fontSize = 20.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
            }
            if (state.reply.isNotBlank()) {
                Text(state.reply, color = Cyan, fontSize = 18.sp, textAlign = TextAlign.Center)
            }
            state.choices.forEach { c ->
                Spacer(Modifier.height(8.dp))
                Button(onClick = { onChoose(c) }, modifier = Modifier.fillMaxWidth()) {
                    Text("${c.name}  ${c.number}")
                }
            }
        }

        if (state.phase != Phase.Idle) {
            OutlinedButton(onClick = onStop) { Text(stringResource(R.string.btn_stop)) }
        }
        Spacer(Modifier.height(24.dp))
    }
}

/** دایره نورانی مرکزی (تصمیم D1): آرام در حالت آماده، موج با صدا هنگام شنیدن، قوس چرخان هنگام پردازش. */
@Composable
fun GlowCircle(phase: Phase, level: Float, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "t")
    val pulse by t.animateFloat(
        0f, 1f, infiniteRepeatable(tween(1600, easing = LinearEasing), RepeatMode.Restart), label = "pulse",
    )
    val spin by t.animateFloat(
        0f, 360f, infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Restart), label = "spin",
    )
    val lv by animateFloatAsState(level, label = "level")
    val desc = stringResource(R.string.mic_desc)

    Box(
        Modifier.size(260.dp)
            .clickable(role = Role.Button, onClick = onClick)
            .semantics { contentDescription = desc },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val base = size.minDimension * 0.27f
            val r = if (phase == Phase.Listening) base * (1f + 0.18f * lv) else base

            drawCircle(
                Brush.radialGradient(listOf(Cyan.copy(alpha = 0.35f), Color.Transparent), center = c, radius = r * 2.2f),
                radius = r * 2.2f, center = c,
            )
            if (phase == Phase.Listening) {
                for (k in 0..1) {
                    val p = (pulse + k * 0.5f) % 1f
                    drawCircle(
                        Cyan.copy(alpha = 0.5f * (1f - p)),
                        radius = r * (1f + 0.9f * p), center = c, style = Stroke(3.dp.toPx()),
                    )
                }
            }
            drawCircle(Cyan.copy(alpha = if (phase == Phase.Idle) 0.85f else 1f), radius = r, center = c)
            if (phase == Phase.Processing) {
                drawArc(
                    Color.White, startAngle = spin, sweepAngle = 100f, useCenter = false,
                    topLeft = Offset(c.x - r * 1.35f, c.y - r * 1.35f),
                    size = Size(r * 2.7f, r * 2.7f),
                    style = Stroke(5.dp.toPx(), cap = StrokeCap.Round),
                )
            }
        }
    }
}

@Composable
private fun statusLabel(s: Status): String = stringResource(
    when (s) {
        Status.DONE -> R.string.status_done
        Status.HANDED_OFF -> R.string.status_handed
        Status.NEEDS_INPUT -> R.string.status_needs
        Status.FAILED -> R.string.status_failed
        Status.UNSUPPORTED -> R.string.status_unsupported
    }
)

@Composable
fun HistoryScreen(items: List<HistoryItem>, onClear: () -> Unit, onBack: () -> Unit) {
    val fmt = remember { SimpleDateFormat("HH:mm  MM/dd", Locale.US) }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text(stringResource(R.string.btn_back)) }
            Text(stringResource(R.string.history_title), color = Color.White, fontSize = 18.sp)
            TextButton(onClick = onClear, enabled = items.isNotEmpty()) { Text(stringResource(R.string.history_clear)) }
        }
        if (items.isEmpty()) {
            Text(stringResource(R.string.history_empty), color = Dim, modifier = Modifier.padding(top = 32.dp))
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(items) { h ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
                        Text("«${h.heard}»", color = Color.White, fontSize = 16.sp)
                        Text(h.reply, color = Cyan, fontSize = 14.sp)
                        Text("${statusLabel(h.status)} · ${fmt.format(Date(h.time))}", color = Dim, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(onClear: () -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    fun granted(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    val mic = remember(tick) { granted(Manifest.permission.RECORD_AUDIO) }
    val contacts = remember(tick) { granted(Manifest.permission.READ_CONTACTS) }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text(stringResource(R.string.btn_back)) }
            Text(stringResource(R.string.settings_title), color = Color.White, fontSize = 18.sp)
            Spacer(Modifier.size(48.dp))
        }
        Spacer(Modifier.height(12.dp))

        PermRow(R.string.perm_mic_title, R.string.perm_mic_why, mic) { launcher.launch(Manifest.permission.RECORD_AUDIO) }
        PermRow(R.string.perm_contacts_title, R.string.perm_contacts_why, contacts) { launcher.launch(Manifest.permission.READ_CONTACTS) }

        OutlinedButton(
            onClick = {
                ctx.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null))
                )
            },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        ) { Text(stringResource(R.string.perm_app_settings)) }

        OutlinedButton(onClick = onClear, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
            Text(stringResource(R.string.history_clear))
        }

        Text(stringResource(R.string.privacy_note), color = Dim, fontSize = 13.sp, modifier = Modifier.padding(top = 24.dp))
        Text(stringResource(R.string.version_note), color = Dim, fontSize = 12.sp, modifier = Modifier.padding(vertical = 16.dp))
    }
}

@Composable
private fun PermRow(title: Int, why: Int, granted: Boolean, onEnable: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp).background(Color(0xFF111111)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(stringResource(title), color = Color.White, fontSize = 16.sp)
            Text(stringResource(why), color = Dim, fontSize = 13.sp)
            Text(
                stringResource(if (granted) R.string.perm_granted else R.string.perm_denied),
                color = if (granted) Cyan else Color(0xFFFF8A80), fontSize = 13.sp,
            )
        }
        if (!granted) TextButton(onClick = onEnable) { Text(stringResource(R.string.perm_enable)) }
    }
}
