package app.ava

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** تاریخچه محلی و کوچک (حداکثر ۱۰۰ مورد). فقط متن؛ صدای خام هرگز ذخیره نمی‌شود. */
class HistoryStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("ava_history", Context.MODE_PRIVATE)

    fun load(): List<HistoryItem> = try {
        val a = JSONArray(prefs.getString("items", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            HistoryItem(o.getLong("t"), o.getString("h"), o.getString("r"), Status.valueOf(o.getString("s")))
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun save(list: List<HistoryItem>) {
        val a = JSONArray()
        list.take(MAX).forEach {
            a.put(JSONObject().put("t", it.time).put("h", it.heard).put("r", it.reply).put("s", it.status.name))
        }
        prefs.edit().putString("items", a.toString()).apply()
    }

    fun clear() {
        prefs.edit().remove("items").apply()
    }

    companion object {
        const val MAX = 100
    }
}
