package app.ava

/**
 * لایه اول: فهم فرمان‌های ساده با منطق محلی، بدون هوش مصنوعی و بدون هزینه.
 * فقط متن را به Command تبدیل می‌کند؛ تصمیم اجرا با Executor است.
 */
object CommandParser {

    fun normalize(raw: String): String = raw.lowercase()
        .replace('‌', ' ')
        .replace('ي', 'ی')
        .replace('ك', 'ک')
        .replace("ۀ", "ه")
        .replace(Regex("[ً-ٟ]"), "")
        .replace(Regex("[.,!?؟،;:\"«»]"), "")
        .replace(Regex("\\s+"), " ")
        .trim()

    private val wake = Regex("^(?:آوا|اوا)\\s+")

    private val callRe = Regex(
        "^(?:(?:به|با)\\s+)?(.+?)\\s+(?:زنگ بزن|زنگ بزنم|تماس بگیر|تماس بگیرم|تماس بزن|شماره بگیر)(?:\\s+لطفا)?$"
    )
    private val openRe = Regex(
        "^(?:(?:برنامه|اپ|اپلیکیشن)\\s+)?(.+?)\\s+(?:رو\\s+)?(?:باز کن|باز کنی|اجرا کن|اجرا کنی)$"
    )

    private val fillers = setOf("آهنگ", "موسیقی", "رو", "را", "این", "لطفا", "یه", "یک")

    private val next = setOf("بعدی", "برو بعدی", "رد کن")
    private val prev = setOf("قبلی", "برو قبلی", "برگرد")
    private val pause = setOf("متوقف کن", "توقف", "استپ", "وایسا", "پاز", "قطع کن", "ساکت کن")
    private val play = setOf("پخش کن", "ادامه بده", "ادامه", "پلی", "پلی کن")
    private val volUp = setOf("صدا زیاد کن", "صدا بلند کن", "صدا بالا ببر", "صدا بیشتر کن")
    private val volDown = setOf("صدا کم کن", "صدا پایین بیار", "صدا آروم کن", "صدا کمتر کن")

    fun parse(raw: String): Command {
        var t = normalize(raw)
        t = wake.replace(t, "")
        if (t.isEmpty()) return Command.Unknown

        // ۱) تماس
        callRe.matchEntire(t)?.let { m ->
            val name = m.groupValues[1].trim()
            if (name.isNotEmpty()) return Command.Call(name)
        }

        // ۲) وای‌فای و بلوتوث
        val wifi = t.contains("وای فای") || t.contains("وایفای")
        val bt = t.contains("بلوتوث")
        if (wifi || bt) {
            val toggle = Regex("روشن|خاموش").containsMatchIn(t)
            val opening = openRe.matches(t)
            if (toggle || opening) {
                return Command.Settings(if (wifi) SettingsKind.WIFI else SettingsKind.BLUETOOTH, toggle)
            }
        }

        // ۳) موسیقی و صدا
        val core = t.split(" ").filter { it !in fillers }.joinToString(" ")
        when (core) {
            in next -> return Command.Media(MediaAction.NEXT)
            in prev -> return Command.Media(MediaAction.PREVIOUS)
            in pause -> return Command.Media(MediaAction.PAUSE)
            in play -> return Command.Media(MediaAction.PLAY)
            in volUp -> return Command.Volume(true)
            in volDown -> return Command.Volume(false)
        }
        val mentionsMusic = t.contains("آهنگ") || t.contains("موسیقی")
        if (mentionsMusic && Regex("پخش|بذار|بزار|بخون|پلی").containsMatchIn(t)) {
            return Command.MusicSearch
        }

        // ۴) باز کردن برنامه یا تنظیمات
        openRe.matchEntire(t)?.let { m ->
            val name = m.groupValues[1].trim()
            if (name.startsWith("تنظیمات")) return Command.Settings(SettingsKind.GENERAL, false)
            if (name.isNotEmpty()) return Command.OpenApp(name)
        }

        return Command.Unknown
    }
}
