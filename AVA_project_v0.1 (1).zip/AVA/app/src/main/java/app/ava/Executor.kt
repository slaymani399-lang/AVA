package app.ava

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.Settings
import android.view.KeyEvent

/**
 * لایه اجرا: فقط کارهای مجاز اندروید را انجام می‌دهد و نتیجه را صادقانه گزارش می‌کند.
 * - تماس: فقط صفحه شماره‌گیر باز می‌شود (بدون CALL_PHONE)، کاربر خودش دکمه تماس را می‌زند.
 * - موسیقی: کلید رسانه‌ای به پخش‌کننده فعال فرستاده می‌شود؛ اندروید نتیجه را گزارش نمی‌دهد، پس HANDED_OFF.
 */
class Executor(private val ctx: Context) {

    private fun s(id: Int, vararg a: Any): String = ctx.getString(id, *a)

    fun execute(cmd: Command): Outcome = when (cmd) {
        is Command.Call -> call(cmd.name)
        is Command.OpenApp -> openApp(cmd.name)
        is Command.Media -> media(cmd.action)
        is Command.Volume -> volume(cmd.up)
        is Command.Settings -> settings(cmd)
        Command.MusicSearch -> Outcome(Status.UNSUPPORTED, s(R.string.r_music_search))
        Command.Unknown -> Outcome(Status.UNSUPPORTED, s(R.string.r_unknown))
    }

    // ---------- تماس ----------

    private fun call(name: String): Outcome {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return Outcome(
                Status.NEEDS_INPUT, s(R.string.r_need_contacts),
                permission = Manifest.permission.READ_CONTACTS,
            )
        }
        val found = findContacts(name)
        if (found.isEmpty()) return Outcome(Status.FAILED, s(R.string.r_call_none, name))
        if (found.size == 1) return dial(found[0])

        val exact = found.filter { CommandParser.normalize(it.name) == CommandParser.normalize(name) }
        if (exact.size == 1) return dial(exact[0])

        return Outcome(Status.NEEDS_INPUT, s(R.string.r_call_multi, name), choices = found.take(5))
    }

    fun dial(c: Contact): Outcome {
        val i = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", c.number, null))
        return if (start(i)) Outcome(Status.HANDED_OFF, s(R.string.r_call_open, c.name))
        else Outcome(Status.FAILED, s(R.string.r_call_fail))
    }

    private fun findContacts(name: String): List<Contact> {
        val variants = linkedSetOf(
            name,
            name.replace('ی', 'ي').replace('ک', 'ك'),
            name.replace(' ', '‌'),
        )
        val result = LinkedHashMap<Long, Contact>()
        val projection = arrayOf(Phone.CONTACT_ID, Phone.DISPLAY_NAME, Phone.NUMBER)
        for (v in variants) {
            ctx.contentResolver.query(
                Phone.CONTENT_URI, projection,
                "${Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$v%"),
                "${Phone.DISPLAY_NAME} ASC",
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    if (!result.containsKey(id)) {
                        result[id] = Contact(id, c.getString(1) ?: "", c.getString(2) ?: "")
                    }
                }
            }
        }
        return result.values.toList()
    }

    // ---------- موسیقی و صدا ----------

    private fun media(a: MediaAction): Outcome {
        val code = when (a) {
            MediaAction.PLAY -> KeyEvent.KEYCODE_MEDIA_PLAY
            MediaAction.PAUSE -> KeyEvent.KEYCODE_MEDIA_PAUSE
            MediaAction.NEXT -> KeyEvent.KEYCODE_MEDIA_NEXT
            MediaAction.PREVIOUS -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
        }
        val am = ctx.getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return Outcome(Status.HANDED_OFF, s(R.string.r_media_sent))
    }

    private fun volume(up: Boolean): Outcome {
        val am = ctx.getSystemService(AudioManager::class.java)
        am.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            AudioManager.FLAG_SHOW_UI,
        )
        return Outcome(Status.DONE, s(R.string.r_volume))
    }

    // ---------- تنظیمات ----------

    private fun settings(c: Command.Settings): Outcome {
        val action = when (c.kind) {
            SettingsKind.WIFI -> Settings.ACTION_WIFI_SETTINGS
            SettingsKind.BLUETOOTH -> Settings.ACTION_BLUETOOTH_SETTINGS
            SettingsKind.GENERAL -> Settings.ACTION_SETTINGS
        }
        if (!start(Intent(action))) return Outcome(Status.FAILED, s(R.string.r_error))
        return Outcome(
            Status.HANDED_OFF,
            s(if (c.toggle) R.string.r_toggle_hint else R.string.r_settings_open),
        )
    }

    // ---------- باز کردن برنامه ----------

    private val aliases = mapOf(
        "یوتیوب" to "youtube", "اینستاگرام" to "instagram", "تلگرام" to "telegram",
        "واتساپ" to "whatsapp", "واتس اپ" to "whatsapp", "کروم" to "chrome",
        "دوربین" to "camera", "نشان" to "neshan", "بله" to "bale", "ایتا" to "eitaa",
        "روبیکا" to "rubika", "گالری" to "gallery", "ماشین حساب" to "calculator",
        "ساعت" to "clock", "اسنپ" to "snapp", "تپسی" to "tapsi", "بازار" to "bazaar",
        "کافه بازار" to "bazaar", "مخاطبین" to "contacts", "پیامک" to "messaging",
        "پیام ها" to "messaging", "شماره گیر" to "dialer", "تلفن" to "dialer",
    )
    private val musicWords = setOf("موسیقی", "آهنگ", "پخش کننده", "پلیر", "مدیا پلیر")

    private fun openApp(name: String): Outcome {
        if (name in musicWords) {
            val i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC)
            if (start(i)) return Outcome(Status.HANDED_OFF, s(R.string.r_app_open, name))
        }
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        val want = CommandParser.normalize(name)
        val alias = aliases[want]

        fun label(r: android.content.pm.ResolveInfo) =
            CommandParser.normalize(r.loadLabel(pm).toString())

        val match = apps.firstOrNull { label(it) == want }
            ?: apps.firstOrNull { label(it).contains(want) }
            ?: alias?.let { a ->
                apps.firstOrNull {
                    label(it).contains(a) || it.activityInfo.packageName.lowercase().contains(a)
                }
            }
        if (match == null) return Outcome(Status.FAILED, s(R.string.r_app_none, name))

        val i = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return Outcome(Status.FAILED, s(R.string.r_app_none, name))
        return if (start(i)) Outcome(Status.HANDED_OFF, s(R.string.r_app_open, name))
        else Outcome(Status.FAILED, s(R.string.r_error))
    }

    private fun start(i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: SecurityException) {
        false
    }
}
