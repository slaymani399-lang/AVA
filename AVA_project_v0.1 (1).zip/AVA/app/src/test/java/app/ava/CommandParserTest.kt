package app.ava

import org.junit.Assert.assertEquals
import org.junit.Test

class CommandParserTest {
    private fun p(s: String) = CommandParser.parse(s)

    @Test fun call() {
        assertEquals(Command.Call("آتنا"), p("به آتنا زنگ بزن"))
        assertEquals(Command.Call("آتنا"), p("آوا، به آتنا زنگ بزن."))
        assertEquals(Command.Call("بهزاد"), p("بهزاد زنگ بزن"))
        assertEquals(Command.Call("محمد رضا"), p("با محمد‌رضا تماس بگیر"))
    }

    @Test fun media() {
        assertEquals(Command.Media(MediaAction.NEXT), p("آهنگ بعدی"))
        assertEquals(Command.Media(MediaAction.PREVIOUS), p("آهنگ قبلی"))
        assertEquals(Command.Media(MediaAction.PAUSE), p("موسیقی رو متوقف کن"))
        assertEquals(Command.Media(MediaAction.PLAY), p("موسیقی رو ادامه بده"))
        assertEquals(Command.Volume(false), p("صدا رو کم کن"))
        assertEquals(Command.Volume(true), p("صدا رو زیاد کن"))
    }

    @Test fun musicSearchUnsupported() {
        assertEquals(Command.MusicSearch, p("یه آهنگ آروم پخش کن"))
    }

    @Test fun apps() {
        assertEquals(Command.OpenApp("یوتیوب"), p("یوتیوب رو باز کن"))
        assertEquals(Command.OpenApp("نشان"), p("برنامه نشان رو باز کن"))
        assertEquals(Command.OpenApp("موسیقی"), p("برنامه موسیقی رو باز کن"))
    }

    @Test fun settings() {
        assertEquals(Command.Settings(SettingsKind.GENERAL, false), p("تنظیمات گوشی رو باز کن"))
        assertEquals(Command.Settings(SettingsKind.BLUETOOTH, true), p("بلوتوث رو روشن کن"))
        assertEquals(Command.Settings(SettingsKind.WIFI, false), p("وای‌فای رو باز کن"))
    }

    @Test fun unknown() {
        assertEquals(Command.Unknown, p("هوا چطوره"))
        assertEquals(Command.Unknown, p(""))
    }
}
